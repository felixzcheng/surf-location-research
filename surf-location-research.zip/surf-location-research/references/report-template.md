# Location and date report contract

Scale the length to the place. Complete the first-use profile setup in SKILL.md before producing a personalized report. Render all status labels and quoted examples in the recipient’s report language. Use the following content, with natural headings only where they help. Omit empty filler, never omit material unknowns.

1. **Verdict first:** best region/season and first spot to investigate for this user's profile. Say whether this is trip planning or a verified current session opportunity. State the resolved requested date or inclusive range, retrieval timestamp with UTC offset, destination timezone, recipient-confirmed profile, unknown fields and any assumptions. For dated requests, lead with the requested-date verdict and time-window table before the destination overview.
2. **Overview:** region distribution, core season and transition months, representative wave types, and 2–3 non-surf activities. Link a provider's spot map.
3. **Shortlist table:** spot and exact section | season | direction/bottom | fit for the recipient’s board, goals and preferences | drawback or invalidating condition | priority/conditional/excluded | evidence confidence. Distinguish the recipient’s preferred practice range from an ability ceiling; leave it unknown when not supplied. Distinguish training suitability from ability to handle a wave.
4. **Top candidate evidence cards:** guide evidence; video link with viewed timestamp or publisher chapter label; filming/publication dates; satellite link and observed geography; map inference; unresolved issues. Supply backup links when a provider is blocked.
5. **Requested-date conditions:** first provide a window table: local date/time | spot/section | observed or forecast surf-face height | swell height/period/direction | wind | tide/station | morning/afternoon preference and reason | takeoff area / evidence-backed approximate distance from shore (or unknown) | suitability and confidence | source. Split into a daily comparison table and detailed windows when that improves readability. A preferred half-day is a relative ranking, not a guarantee; allow both/neither/uncertain, and mark unavailable outside forecast coverage. Explain any inferred clock windows. For distance, include the shoreline reference, tide/date and uncertainty when measured; otherwise state “距岸米数未核实，按当天破浪线定位”. Mark missing values unknown. Then give the evidence ledger: source/account | observation vs forecast | posted/issued date | filmed/valid date and local time | exact spot confidence | finding | freshness/access status. For today, show observation age; when no fresh observation exists, explicitly conclude “近期实际浪况未核实”. Label future rows “预报”, past rows “历史观测” or “历史模型”, and dates outside the forecast horizon “仅季节参考，具体日期预报未开放”. Split mixed ranges and disclose uncovered dates. Never label future forecasts real-time conditions. List a few useful verified accounts, not invented usernames.
6. **Practical decision:** a conservative fallback suited to the supplied profile; direction options matching stated preferences; what to exclude; what must be checked on arrival. Avoid generic safety essays. If local input would resolve a specific gap, include one ready-to-copy question without sending it: “For [spot/section], do you have a continuous clip filmed today showing the takeoff and several sets? I ride [board], my level is [level], and my goals are [goals]. I prefer [wave characteristics and size]. What are the tide, bottom and entry conditions?” Fill only recipient-supplied fields and omit unknown ones.
7. **Evidence limits:** distinguish footage viewed from links merely found; identify missing forecasts, unavailable Stories, unknown image capture dates and material source conflicts. Link all material claims locally, not just in a bibliography.

## Behavioral checks during skill revision

- `Sri Lanka` on first use: ask for the recipient’s profile before research. After setup, show both coastal seasons and do not invent travel dates or a default preferred spot.
- `Bali` only: research Bali from live sources; do not inherit Sri Lanka's monsoon months, forecast thresholds or spot ranking.
- A named bay containing reef and sand peaks: don't classify every section using a single beginner-friendly label.
- A latest forecast dated three weeks ago: reject it as a current forecast, even if it says today.
- Instagram shows only old pinned reels: list the account as a lead, not a recent observation.
- User asks for powerful lefts: apply that preference with their supplied level and board, without imposing longboard-training goals.
- Only a mountain-backed satellite image is available: mark suitability unknown; do not infer a mellow or safe wave.

- `Mirissa today`: resolve the calendar date, show destination timezone and retrieval timestamp, separate observed conditions from remaining daylight forecasts; report missing live evidence honestly.
- `Weligama tomorrow`: provide only forecasts for the resolved date, not claims of observed future waves.
- `Sri Lanka 2027-06-01 to 2027-06-07` when outside the provider horizon: give seasonal guidance and no invented hourly conditions.
- A range spanning yesterday through next month: separate historical evidence, forecast coverage and seasonal-only dates.
- A past date with no accessible archive: mark unavailable rather than substituting current data.

- A regular-foot user requests frontside practice: assess suitable rights; do not inherit another user's left preference.
- A user requests longboard cross-stepping: evaluate sustained push and open shoulders. A shortboard user with different goals receives a different ranking.
- Unknown stance, board or wave-size preference: retain unknowns rather than filling in a personal default.
- First-use user explicitly declines setup: provide only general suitability, with personalization limits stated.
- Returning user in the same conversation: reuse their supplied profile and apply corrections without repeating the full questionnaire.
- Self-reported large-wave experience: retain as context, not a verified skill rating or blanket clearance for large/hollow surf.

- Morning has weaker wind but afternoon has better swell/tide: compare the tradeoff; do not automatically select morning or promise an exact best hour from half-day data.
- No measured takeoff position: describe the working breaking line and mark distance unknown, rather than suggesting a generic 50–100 m paddle.
